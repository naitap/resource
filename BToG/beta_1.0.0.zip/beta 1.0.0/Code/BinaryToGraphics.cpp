/*
 *  BinaryToGraphics Version Beta 1.0.0 (Build 001).
 *  Copyright (c) NaiTap Studio.
*/

#include "btog.h"

int main(int argc, char** argv)
{
	btog(argc, argv);
}