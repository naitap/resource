/*
 *  BinaryToGraphics Version Beta 1.0.0 (Build 001).
 *  Copyright (c) NaiTap Studio.
*/

#include "btog.h"
using namespace std;

int Is(int argc, char** argv, string c)
{
	for (int i = 1; i < argc; i++)
	{
		if (argv[i] == c) { return i + 1; }
	}
}

bool Search(int argc, char** argv, string c)
{
	for (int i = 1; i < argc; i++)
	{
		if (argv[i] == c) { return true; }
	}
	return false;
}

void DrawGraph(char binary, int COLOR, string TEXT)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), COLOR);
	cout << TEXT;
}

void Version()
{
	cout << "\n" << endl;
	cout << "BinaryToGraphics Version Beta 1.0.0 (Build 001)." << endl;
	cout << "Copyright(c) NaiTap Studio." << endl;
}

void Output(int argc, char** argv, int mode)
{
	string binary = argv[Is(argc, argv, "-b")]; string TEXT;
	int lb = atoi(string(argv[Is(argc, argv, "-lb")]).c_str());

	if (mode == 1) TEXT = argv[Is(argc, argv, "-t")];
	if (mode == 1 && Search(argc, argv, "-dev")) { cout << "binary:" << binary << endl; cout << "length: " << binary.length() << endl; cout << "line break:" << lb << endl; }

	for (int i = 0; i < binary.length(); i++)
	{
		if (i % lb == 0)
		{
			cout << endl;
		}

		if (binary[i] == '0')
		{
			if (mode == 0) { DrawGraph(binary[i], W, "#"); }
			if (mode == 1) { DrawGraph(binary[i], W, TEXT); }
		}
		if (binary[i] == '1')
		{
			if (mode == 0) { DrawGraph(binary[i], B, "#"); }
			if (mode == 1) { DrawGraph(binary[i], B, TEXT); }
		}
	}

	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), W | B | E);
	if (mode == 1 && Search(argc, argv, "-v")) { Version(); }
}

void btog(int argc, char** argv)
{
	if (argc == 2 && argv[1] == "-v") { Version(); }
	if (argc < 5 && argc > 3) { cout << "error!" << endl; }
	if (argc == 4) { Output(argc, argv, 0); }
	if (argc > 5) { Output(argc, argv, 1); }

	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), W | B | E);
	cout << "\n";
}