/*
 *  BinaryToGraphics Version Beta 1.0.1 (Build 002).
 *  Copyright (c) NaiTap Studio.
*/

#include "btog.h"

int main(int argc, char** argv)
{
	btog(argc, argv);
}