/*
 *  BinaryToGraphics Version Beta 1.0.1 (Build 002).
 *  Copyright (c) NaiTap Studio.
*/

#include <iostream>
#include <Windows.h>

#define W FOREGROUND_GREEN
#define B FOREGROUND_RED
#define E FOREGROUND_BLUE

void btog(int argc, char** argv);