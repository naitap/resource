/*
 *  BinaryToGraphics Version Beta 1.0.2 (Build 003).
 *  Copyright (c) NaiTap Studio.
*/

#include "BToG.h"
using namespace std;

int Is(int argc, char** argv, string c)
{
	for (int i = 1; i < argc; i++)
	{
		if (argv[i] == c) { return i + 1; }
	}
}

bool Search(int argc, char** argv, string c)
{
	for (int i = 1; i < argc; i++)
	{
		if (argv[i] == c) { return true; }
	}
	return false;
}

void DrawGraph(char binary, int COLOR, string TEXT)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), COLOR);
	cout << TEXT;
}

void Version()
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), G);
	cout << "BinaryToGraphics Version 1.0.2 (Build 002)." << endl;
	cout << "Copyright(c) NaiTap Studio." << endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), R | G | B);
}

int SetColor(string color)
{
	if (color == "red") { return 4; }
	if (color == "green") { return 2; }
	if (color == "blue") { return 1; }
}

void Output(int argc, char** argv)
{
	string binary = argv[Is(argc, argv, "-b")];
	string TEXT = argv[Is(argc, argv, "-t")];

	int c0, c1; c0 = G; c1 = R;
	int lb = atoi(string(argv[Is(argc, argv, "-lb")]).c_str());

	if (Search(argc, argv, "-c0"))
	{
		c0 = SetColor(argv[Is(argc, argv, "-c0")]);
	}
	if (Search(argc, argv, "-c1"))
	{
		c1 = SetColor(argv[Is(argc, argv, "-c1")]);
	}
	
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), G);
	if (Search(argc, argv, "/dev"))
	{
		cout << "\n";
		cout << "binary:" << binary << endl;
		cout << "length: " << binary.length() << endl;
		cout << "line break:" << lb << endl;
	}
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), R | G | B);

	for (int i = 0; i < binary.length(); i++)
	{
		if (i % lb == 0)
		{
			cout << endl;
		}

		if (binary[i] == '0') { DrawGraph(binary[i], c0, TEXT); }
		if (binary[i] == '1') { DrawGraph(binary[i], c1, TEXT); }
	}

	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), R | G | B);
	cout << "\n";
}

int main(int argc, char** argv)
{
	if (argc == 2 && Search(argc, argv, "/v"))
	{
		Version();
		return 0; 
	}
	if (argc > 5) { Output(argc, argv); }

	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), R | G | B);
	cout << "\n";
	return 0;
}