/*
 *  BinaryToGraphics Version Beta 1.0.1 (Build 002).
 *  Copyright (c) NaiTap Studio.
*/

#include <iostream>
#include <Windows.h>

#define R 0x0004
#define G 0x0002
#define B 0x0001