/*
 *  BinaryToGraphics ColorExist 1.0
 *  Copyright (c) NaiTap Studio.
 */

#include <iostream>
using namespace std;

bool isExist(int len, char** par, string exist)
{
	for (int i = 0; i < len; i++)
	{
		if (par[i] == exist)
		{
			return true;
		}
	}
	return false;
}

int main(int argc, char* argv[])
{
	if (isExist(argc, argv, "red")) { return true; }
	else if (isExist(argc, argv, "green")) { return true; }
	else if (isExist(argc, argv, "blue")) { return true; }
	else if (isExist(argc, argv, "white")) { return true; }
	else { return false; }
}