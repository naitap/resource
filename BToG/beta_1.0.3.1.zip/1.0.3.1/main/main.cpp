/*
 *  BinaryToGraphics version beta 1.0.3.1 build 14
 *  Copyright (c) NaiTap Studio.
 */

#include <iostream>
#include <regex>
#include <Windows.h>
using namespace std;

int isExist(int len, char** par, string exist)
{
	for (int i = 0; i < len; i++)
	{
		if (par[i] == exist)
		{
			return i;
		}
	}
	return -1;
}

int main(int argc, char** argv)
{
	if (argc == 1)
	{
		cout << "BinaryToGraphics �汾 beta 1.0.3" << endl;
		system("pause");
		return 1;
	}

	string error = "������﷨����!";
	string c0, c1;
	if (isExist(argc, argv, "-c0") != -1)
		c0 = argv[isExist(argc, argv, "-c0") + 1];
	if (isExist(argc, argv, "-c1") != -1)
		c1 = argv[isExist(argc, argv, "-c1") + 1];

	if (isExist(argc, argv, "-v") != -1)
	{
		cout << "\nBinaryToGraphics �汾 beta 1.0.3" << endl;
		cout << "�ڲ��汾 004  ��������" << endl;
		cout << "��Ȩ���� (c) NaiTap Studio.\n" << endl;
		return 1;
	}
	if (isExist(argc, argv, "-b") == -1 ||
		isExist(argc, argv, "-lb") == -1 ||
		isExist(argc, argv, "-t") == -1) { cout << error << endl; return -1; }

	string path_c0 = "cexist.exe " + c0;
	string path_c1 = "cexist.exe " + c1;
	bool tc0 = system(path_c0.data());
	bool tc1 = system(path_c1.data());

	if (!tc0 && isExist(argc, argv, "-c0") != -1)
	{
		cout << "-c0 " << c0 << endl;
		cout << "    ^" << "  δ֪����ɫ: " << c0 << endl;
		return -1;
	}

	if (!tc1 && isExist(argc, argv, "-c1") != -1)
	{
		cout << "-c1 " << c1 << endl;
		cout << "    ^" << "  δ֪����ɫ: " << c1;
		return -1;
	}

	regex num("\\D{0,}");
	regex r_binary("[2-9]|\\D{0,}");

	string binary = regex_replace(argv[isExist(argc, argv, "-b") + 1], r_binary, "");
	string lineBreak = regex_replace(argv[isExist(argc, argv, "-lb") + 1], num, "");
	string text = argv[isExist(argc, argv, "-t") + 1];
	string path_r = "show.exe " + binary + " " + lineBreak + " " + text;

	if (isExist(argc, argv, "-c0") != -1)
		path_r = path_r + " " + c0;
	else
		path_r = path_r + " " + "red";
	if (isExist(argc, argv, "-c1") != -1)
		path_r = path_r + " " + c1;
	else
		path_r = path_r + " " + "green";

	if (isExist(argc, argv, "-dev") != -1)
	{
		cout << "\nDev Mode:" << endl;
		cout << "path = " << binary + " " + lineBreak + " " + text + " " + c0 + " " + c1 << endl;
		cout << "binary = " << binary << endl;
		cout << "line break = " << lineBreak << endl;
		cout << "text = " << text << endl;
		cout << "\n";
	}

	system(path_r.data());

	return 0;
}

/*
return:
	-1 -- Error
	0 -- Finish
	1 -- Version
*/