/*
 *  BinaryToGraphics Show 1.0
 *  Copyright (c) NaiTap Studio.
 */

#include <iostream>
#include <windows.h>
using namespace std;

#define R FOREGROUND_RED
#define G FOREGROUND_GREEN
#define B FOREGROUND_BLUE

int color(string c)
{
	if (c == "red")
		return R;
	else if (c == "green")
		return G;
	else if (c == "blue")
		return B;
	else if (c == "white")
		return R | G | B;
}

bool isExist(int len, char** par, string exist)
{
	for (int i = 0; i < len; i++)
	{
		if (par[i] == exist)
		{
			return true;
		}
	}
	return false;
}

int main(int argc, char** argv)
{
	string path_c0 = "cexist.exe " + (string)argv[4];
	string path_c1 = "cexist.exe " + (string)argv[5];
	bool tc0 = system(path_c0.data());
	bool tc1 = system(path_c1.data());

	string bry = argv[1];
	string lb = argv[2];
	int i_lb = atoi(lb.c_str());
	for (int i = 0; i <= bry.length(); i++)
	{
		if (i % i_lb == 0) { cout << endl; }
		if (bry[i] == '0')
		{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color(argv[4]));
			cout << argv[3];
		}
		if (bry[i] == '1')
		{
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color(argv[5]));
			cout << argv[3];
		}
	}
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), R | G | B);

	return 1;
}